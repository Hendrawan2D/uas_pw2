<?php $__env->startSection('content'); ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Data Alternatif</h4>
                  <p class="card-description">
                    Menampilkan Semua Data Alternatif
                  </p>
                  <a class="btn btn-success btn-rounded btn-fw" href="<?php echo e(url ('/alternatif/tambah')); ?>"> Tambah Alternatif</a>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>
                            No
                          </th>
                          <th>
                            Nama Alternatif
                          </th>
                          <th>
                            Deskripsi
                          </th>
                          <th>
                            Harga
                          </th>
                          <th>
                            Kualitas
                          </th>
                          <th>
                            Kemasan
                          </th>
                          <th>
                            Daya Tahan
                          </th>
                          <th>
                            Kemudahan Pengiriman
                          </th>
                          <th>
                            Aksi
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php $__currentLoopData = $alternatif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name_column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($name_column->nama); ?></td>
                                        <td><?php echo e($name_column->deskripsi); ?></td>
                                        <td><?php echo e($name_column->harga); ?></td>
                                        <td><?php echo e($name_column->kualitas); ?></td>
                                        <td><?php echo e($name_column->kemasan); ?></td>
                                        <td><?php echo e($name_column->daya_tahan); ?></td>
                                        <td><?php echo e($name_column->kemudahan_pengiriman); ?></td>

                                        <td>
                                            <?php echo csrf_field(); ?>
                                                 <a href="/alternatif/<?php echo e($name_column->id); ?>/edit" data-tip="edit" type="button" class="btn btn-outline-warning btn-sm">Edit</a>
                                                 <a href="/alternatif/<?php echo e($name_column->id); ?>/delete"  type="button" class="btn btn-outline-danger btn-sm">Hapus</a>
                                        </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/idham/Downloads/project_uts/resources/views/dashboard/alternatif/index.blade.php ENDPATH**/ ?>