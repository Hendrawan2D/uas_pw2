<?php $__env->startSection('content'); ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Data Kriteria</h4>
                  <p class="card-description">
                    Menampilkan Semua Data Kriteriap
                  </p>
                  <a class="btn btn-success btn-rounded btn-fw" href="<?php echo e(url ('/kriteria/tambah')); ?>"> Tambah Kriteria</a>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>
                            No
                          </th>
                          <th>
                            Nama Kriteria
                          </th>
                          <th>
                            Bobot
                          </th>
                          <th>
                            Label
                          </th>
                          <th>
                            Aksi
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                       <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name_column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($name_column->nama); ?></td>
                                        <td><?php echo e($name_column->bobot); ?></td>
                                        <td><?php echo e($name_column->label); ?></td>

                                        <td>
                                            <?php echo csrf_field(); ?>
                                            
                                                

                                                 <a href="/kriteria/<?php echo e($name_column->id); ?>/edit" data-tip="edit" type="button" class="btn btn-outline-warning btn-sm">Edit</a>
                                                 <a href="/kriteria/<?php echo e($name_column->id); ?>/delete"  type="button" class="btn btn-outline-danger btn-sm">Hapus</a>
                                            
                                            
                                        </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/idham/Downloads/project_uts/resources/views/dashboard/kriteria/index.blade.php ENDPATH**/ ?>