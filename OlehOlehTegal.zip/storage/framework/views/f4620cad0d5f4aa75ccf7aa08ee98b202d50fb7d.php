<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <title><?php echo e($title); ?> | SPK Pemilihan Studio</title>

    <!-- Bootstrap core CSS -->
    

    
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    

    <!-- Bootstrap CSS -->
    

    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Style -->
    <link rel="stylesheet" href="/assetsLogin/css/style.css">

    

<!-- Custom styles for this template -->
    
  </head>
  <body class="text-center">
    <?php echo $__env->yieldContent('content'); ?>
  </body>

  
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  

  
  
  <script src="/assetLogin2/js/jquery.min.js"></script>
  <script src="/assetsLogin/js/popper.js"></script>
  <script src="/assetsLogin/js/bootstrap.min.js"></script>
  <script src="/assetsLogin/js/main.js"></script>

  
  <?php if(session()->has('success')): ?>
    <script>
      Swal.fire({
        icon: 'success',
        title: 'Success',
        text: "<?php echo e(session('success')); ?>",
      });
    </script>
  <?php endif; ?>

  <?php if(session()->has('failed')): ?>
    <script>
      Swal.fire({
        icon: 'error',
        title: 'Failed',
        text: "<?php echo e(session('failed')); ?>",
      });
    </script>
  <?php endif; ?>
</html>
<?php /**PATH /home/idham/Downloads/project_uts/resources/views/layouts/auth.blade.php ENDPATH**/ ?>