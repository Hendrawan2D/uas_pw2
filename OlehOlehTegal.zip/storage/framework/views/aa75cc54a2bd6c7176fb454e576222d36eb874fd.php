<?php $__env->startSection('content'); ?>
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Hasil Pethitungan</h4>
                  <p class="card-description">
                    Menampilkan Normalisasi Dan Hasil
                  </p>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>
                            No
                          </th>
                          <th>
                            Nama Alternatif
                          </th>
                          <th>
                            Harga
                          </th>
                          <th>
                            Kualitas
                          </th>
                          <th>
                            Kemasan
                          </th>
                          <th>
                            Daya Tahan
                          </th>
                          <th>
                            Kemudahan Pengiriman
                          </th>
                          <th>
                            Hasil
                          </th>
                        </tr>
                      </thead>
                      <tbody>
             <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($result['nama_alt']); ?></td>
                                    <td><?php echo e($result['harga']); ?></td>
                                    <td><?php echo e($result['kualitas']); ?></td>
                                    <td><?php echo e($result['kemasan']); ?></td>
                                    <td><?php echo e($result['daya_tahan']); ?></td>
                                    <td><?php echo e($result['kemudahan_pengiriman']); ?></td>
                                    <td><?php echo e($result['hasil']); ?></td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/idham/Downloads/project_uts/resources/views/dashboard/hasil/hasil.blade.php ENDPATH**/ ?>